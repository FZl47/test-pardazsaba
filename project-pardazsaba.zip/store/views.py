from django.shortcuts import render, redirect
from django.views.decorators.http import require_POST
from django.db.models import F
from django.contrib import messages
from . import models, forms


def _success_add_message(request):
    messages.success(request, 'عملیات ثبت با موفقیت انجام شد')

def add_view(request):
    context = {
        'phone_form': forms.AddPhoneForm,
        'phone_quantity_form': forms.AddPhoneQuantityForm,
        'brand_form': forms.AddBrandForm,
    }
    return render(request, 'store/add.html', context)


@require_POST
def add_phone(request):
    form = forms.AddPhoneForm(request.POST)
    if not form.is_valid():
        messages.error(request,'لطفا فیلد های فرم ثبت موبایل را به درستی وارد نمایید')
    form.save()
    _success_add_message(request)
    return redirect('store:add')


@require_POST
def add_phone_quantity(request):
    form = forms.AddPhoneQuantityForm(request.POST)
    if not form.is_valid():
        messages.error(request, 'لطفا فیلد های فرم ثبت موجودی موبایل را به درستی وارد نمایید')
    form.save()
    _success_add_message(request)
    return redirect('store:add')


@require_POST
def add_brand(request):
    form = forms.AddBrandForm(request.POST)
    if not form.is_valid():
        messages.error(request, 'لطفا فیلد های فرم ثبت برند را به درستی وارد نمایید')
    form.save()
    _success_add_message(request)
    return redirect('store:add')


def reports_view(request):
    context = {
        'korea_brands': models.Brand.objects.filter(nationality='Korea'),
        'form_search_phone': forms.SearchPhone,
        'nationality_and_make_country_phones': models.Phone.objects.filter(brand__nationality=F('make_country'))
    }

    if request.method == 'POST':
        # search phone
        form = forms.SearchPhone(request.POST)
        if form.is_valid():
            brand_name = form.data.get('brand_name','')
            # search phone by brand name and sort by greatest count
            phones = models.Phone.objects.filter(brand__name__contains=brand_name).order_by('-phonequantity__count').distinct()
            context['search_phones'] = phones
            context['search_brand'] = brand_name
        else:
            context['search_phones'] = []
    return render(request,'store/reports.html',context)
