from django.contrib import admin
from . import models

admin.site.register(models.Phone)
admin.site.register(models.PhoneQuantity)
admin.site.register(models.Brand)