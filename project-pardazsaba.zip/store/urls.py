from django.urls import path
from . import views

app_name = 'store'
urlpatterns = [
    # Add
    path('add',views.add_view,name='add'),
    path('add/brand',views.add_brand,name='add_brand'),
    path('add/phone',views.add_phone,name='add_phone'),
    path('add/phone/quantity',views.add_phone_quantity,name='add_phone_quantity'),
    # Reports
    path('reports',views.reports_view,name='reports')
]