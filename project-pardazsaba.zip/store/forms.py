from django.forms import ModelForm
from django import forms
from . import models


class AddPhoneForm(ModelForm):
    class Meta:
        model = models.Phone
        fields = '__all__'
        labels = {
            'name': 'نام',
            'brand': 'نوع برند',
            'display_size': 'سایز صفحه نمایش',
            'make_country': 'کشور سازنده',
        }


class AddPhoneQuantityForm(ModelForm):
    color_hex = forms.CharField(max_length=7,min_length=7,
                          label='کد رنگ',
                          required=False,
                          widget=forms.TextInput(attrs={'type': 'color'}))

    class Meta:
        model = models.PhoneQuantity
        fields = '__all__'
        labels = {
            'phone': 'موبایل',
            'price': 'قیمت',
            'color': 'رنگ',
            'count': 'تعداد موجودی',
        }


class AddBrandForm(ModelForm):
    class Meta:
        model = models.Brand
        fields = '__all__'
        labels = {
            'name':'نام برند',
            'nationality': 'ملیت'
        }


class SearchPhone(forms.Form):
    brand_name = forms.CharField(max_length=100,required=True,label='نام برند')
