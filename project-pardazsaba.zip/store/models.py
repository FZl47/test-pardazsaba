from django.db import models
from django.core.validators import MinValueValidator


class BaseModel(models.Model):
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        abstract = True


class Store(BaseModel):
    """
        created base store model for use in store phone or ...
    """
    ...

    class Meta:
        abstract = True


class Brand(BaseModel):
    name = models.CharField(max_length=100)
    nationality = models.CharField(max_length=100)

    def __str__(self):
        return self.name


class Phone(Store):
    brand = models.ForeignKey('Brand', on_delete=models.CASCADE)
    name = models.CharField(max_length=200, unique=True)
    display_size = models.FloatField(validators=[MinValueValidator(0)])
    make_country = models.CharField(max_length=20)

    def __str__(self):
        return self.name

    def get_quantities(self):
        quantities = self.phonequantity_set.all()
        # get quantities with available
        quantities = quantities.filter(count__gt=0)
        return quantities

    def have_quantity(self):
        return self.get_quantities().exists()

    def get_lowest_price(self):
        q = self.get_quantities().order_by('price').first()
        if q:
            return q.get_price
        return 0.0


class PhoneQuantity(BaseModel):
    """
        created for phone quantity with difference color and price
    """
    phone = models.ForeignKey('Phone', on_delete=models.CASCADE)
    price = models.PositiveBigIntegerField()
    color = models.CharField(max_length=20, default='white')
    color_hex = models.CharField(max_length=8, default='#ffffff', null=True, blank=True)
    count = models.PositiveIntegerField(default=1)

    def __str__(self):
        return f'{self.phone} - {self.count} - {self.color} - {self.get_price}'

    @property
    def get_price(self):
        # for get price | maybe have discount or .. and need to calculation
        return self.price
